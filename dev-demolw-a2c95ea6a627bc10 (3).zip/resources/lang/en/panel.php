<?php

return [
    'site_title' => 'DemoLW',
];
